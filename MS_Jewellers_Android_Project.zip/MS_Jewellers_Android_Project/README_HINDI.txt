MS JEWELLERS ANDROID PROJECT
============================

यह Android Studio में खोलने योग्य प्रोजेक्ट है। इसमें आपकी दी हुई HTML calculator फाइल ऐप के अंदर रखी गई है और ऐप WebView के माध्यम से ऑफलाइन चलती है।

महत्वपूर्ण:
1. यह अभी Android project source है, compiled APK नहीं।
2. APK बनाने के लिए Android Studio और Android SDK/Gradle की जरूरत होगी।
3. Android Studio में इस फोल्डर को Open करें, Gradle Sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk में बनेगी।
6. फोन में APK इंस्टॉल करने के लिए उसे फोन में भेजें और अनुमति मिलने पर Install करें।

मौजूदा HTML की गणना और UI यथावत रखे गए हैं। प्रिंट बटन को Android Print framework से जोड़ा गया है।

LICENSE / SECURITY LIMITATION:
मौजूदा HTML में demo activation key MSJ-2026-002 और localStorage आधारित 24 घंटे का demo lock है। यह सुरक्षित server-side licensing नहीं है और इसे APK से निकालकर या बदलकर bypass किया जा सकता है। Firebase license verification अभी इस project में integrate नहीं है। इसे production/customer distribution से पहले सुरक्षित Firebase/Cloud Function verification से बदलना चाहिए।

Package: com.msjewellers.calculator
App name: MS Jewellers
Minimum Android: 6.0 (API 23)
